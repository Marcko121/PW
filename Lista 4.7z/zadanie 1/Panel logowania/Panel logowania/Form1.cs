﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Panel_logowania
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void Form1_Load(object sender, EventArgs e)
        {
            
        }
        public void button1_Click(object sender, EventArgs e)
            {
            
                string uzytkownik = textBox1.Text;
                string haslo = textBox2.Text;

                if (SprawdzNazweiHaslo(uzytkownik, haslo))
                {
                MessageBox.Show("Zalogowano", "Zalogowano");
                return;

                }
                else
                {
                    MessageBox.Show("Nie zalogowno, złe hasło", "Nie zalogowno, złe hasło");
                    return;
                }

               
            }
        public bool SprawdzNazweiHaslo(string uzytkownik, string haslo)
        {


            if (uzytkownik == "admin" & haslo == "admin1" || uzytkownik == "uzytkownik" & haslo == "uzytkownik1" || uzytkownik == "uzytkownik2" & haslo == "uzytkownik2")
        
                return true;
            
            else
                return false;


           



        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
    }

