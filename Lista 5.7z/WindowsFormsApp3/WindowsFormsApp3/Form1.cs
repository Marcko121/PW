﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=komis;";
            string query = "SELECT * FROM samochody";

            MySqlConnection databaseConnection = new MySqlConnection(connectionString);
            MySqlCommand commandDatabase = new MySqlCommand(query, databaseConnection);
            commandDatabase.CommandTimeout = 60;
            MySqlDataReader reader;
            listBox1.Items.Clear();
            try
            {
                databaseConnection.Open();

                reader = commandDatabase.ExecuteReader();

                if (reader.HasRows)
                {
                    MessageBox.Show("Udało się!");
                    while (reader.Read())
                    {

                        string[] row = { reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetString(3), reader.GetString(4), reader.GetString(5) };
                        listBox1.Items.Add(row[0] + " " + row[1] + " " + row[2] + " " + row[3] + " " + row[4] + " " + row[5]);
                    }
                }
                else
                {
                    MessageBox.Show("Brak rekordów!");
                }
                databaseConnection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
        private void button3_Click(object sender, EventArgs e)
        {
            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=komis;";
            string query = "DELETE FROM samochody WHERE id=?id;";

            MySqlConnection databaseConnection = new MySqlConnection(connectionString);
            MySqlCommand commandDatabase = new MySqlCommand(query, databaseConnection);
            commandDatabase.CommandTimeout = 60;
        

            try
            {
                databaseConnection.Open();
                commandDatabase.Parameters.Add("?id", MySqlDbType.Int32).Value = Convert.ToInt32(textBox6.Text);
                commandDatabase.ExecuteNonQuery();

                MessageBox.Show("Usunięto " + textBox6.Text + " rekord");

                databaseConnection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            listBox1.Items.Clear();


        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=komis;";
            string query = "INSERT INTO samochody(marka,model,pojemnosc,kolor,cena) VALUES (?marka,?model,?pojemnosc,?kolor,?cena);";

            MySqlConnection databaseConnection = new MySqlConnection(connectionString);
            MySqlCommand commandDatabase = new MySqlCommand(query, databaseConnection);
            commandDatabase.CommandTimeout = 60;


            try
            {
                databaseConnection.Open();


                commandDatabase.Parameters.Add("?marka", MySqlDbType.VarChar).Value = textBox1.Text;
                commandDatabase.Parameters.Add("?model", MySqlDbType.VarChar).Value = textBox2.Text;
                commandDatabase.Parameters.Add("?pojemnosc", MySqlDbType.Int32).Value = Convert.ToInt32(textBox3.Text);
                commandDatabase.Parameters.Add("?kolor", MySqlDbType.VarChar).Value = textBox4.Text;
                commandDatabase.Parameters.Add("?cena", MySqlDbType.Int32).Value = Convert.ToInt32(textBox5.Text);
                commandDatabase.ExecuteNonQuery();

                MessageBox.Show("Dodano rekord : " + textBox1.Text + " " + textBox2.Text);

                databaseConnection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            listBox1.Items.Clear();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=komis;";
            string query = "SELECT * FROM samochody order by cena";

            MySqlConnection databaseConnection = new MySqlConnection(connectionString);
            MySqlCommand commandDatabase = new MySqlCommand(query, databaseConnection);
            commandDatabase.CommandTimeout = 60;
            MySqlDataReader reader;

            try
            {
                listBox1.Items.Clear();
                databaseConnection.Open();

                reader = commandDatabase.ExecuteReader();

                if (reader.HasRows)
                {
                    MessageBox.Show("Wczytano");
                    listBox1.Items.Clear();
                    listBox1.Items.Add("id; cena; marka; nazwa; pojemnosc; kolor");
                    listBox1.Items.Add(" ");
                    while (reader.Read())
                    {
                        
                        string[] row = { reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetString(3), reader.GetString(4), reader.GetString(5) };
                        listBox1.Items.Add(row[0] + " " + row[5] + " " + row[1] + " " + row[2] + " " + row[3] + " " + row[4]);
                    }
                }
                else
                {
                    MessageBox.Show("Brak rekordów!");
                }
                databaseConnection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
       
    }
}
